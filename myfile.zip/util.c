#include "util.h"

int symhash(char * sym)
{
  unsigned int hash=0;
  unsigned c;
  while(c==*sym++) hash=hash*9^c;

  return hash;
}


struct symbol *
lookup(char * sym)
{
  struct symbol *sp=&symtab[symhash(sym)%NHASH];
  int scount=NHASH;
  while(--scount>=0){
   if(sp->name!=NULL&&strcmp(sp->name,sym)==0){return sp;}
   if(!sp->name){
      sp->name=strdup(sym);
	  sp->value=0;
	  sp->type=0;
	  sp->v='0';
	  return sp;
   }
   if(++sp>=symtab+NHASH)sp=symtab;
  }
  /*symbol table is full */
  fprintf(stderr,"symbol table is full\n");
  abort();
}
struct symbol*
search(char * sym)
{
  struct symbol *sp=&symtab[symhash(sym)%NHASH];
  int scount=NHASH;
  while(--scount>=0){
   if(sp->name!=NULL&&strcmp(sp->name,sym)==0){return sp;}
   if(!sp->name){
     return NULL;
   }
   if(++sp>=symtab+NHASH)sp=symtab;
  }

}
/*
 * add type to a given ID
 * return 0 for sucess
 * -1 for falure
 */
int addType(char* sym,int type)
{
	printf("ID %s type %d\n",sym,type);
	if(type!=0&&type!=1&&type!=2&&type!=3)
	{
      printf("Invalid type passed\n");
	  return -1;
	}
   struct symbol *sp=&symtab[symhash(sym)%NHASH];
  int scount=NHASH;
  while(--scount>=0){
   if(sp->name!=NULL&&strcmp(sp->name,sym)==0){sp->type=type;return 0;}
   if(!sp->name){
	 printf("Invalid ID passed\n");
     return -1;
   }
    if(++sp>=symtab+NHASH)sp=symtab;
   }
}
/*
 * add value to a given ID
 * return 0 for sucess
 * -1 for falure
 */
int addValue(char* sym,int value,char v)
{
   struct symbol *sp=&symtab[symhash(sym)%NHASH];
  int scount=NHASH;
  while(--scount>=0){
   if(sp->name!=NULL&&strcmp(sp->name,sym)==0){
	   if(sp->type=1)
	     sp->value=value;
	   else
		 sp->v=v;
	   return 0;
   }
   if(!sp->name){
	 printf("Invalid ID passed\n");
     return -1;
   }
   if(++sp>=symtab+NHASH)sp=symtab;
  }
}
/*getType for a given ID
 * return Type if sucess
 * -1 failure
 */
int getType(char * sym)
{
   struct symbol *sp=&symtab[symhash(sym)%NHASH];
  int scount=NHASH;
  while(--scount>=0){
   if(sp->name!=NULL&&strcmp(sp->name,sym)==0){
	 return sp->type; 
   }
   if(!sp->name){
	 printf("Invalid ID passed\n");
     return -1;
   }
  if(++sp>=symtab+NHASH)sp=symtab;
  }
}
void init_symtab()
{
  int i;
  for(i=0;i<NHASH;i++)
  {
   symtab[i].name=NULL;
   symtab[i].value=0;
   symtab[i].v='0';
   symtab[i].type=0;
  }
}

void get_temp_var(struct TreeNode* t)
{
  if(t->nodekind!=ExpK)
	return;
  if(t->kind!=OpK);
	return;
  if((t->attr.op<PLUS||t->attr.op>OVER)&&t->attr.op!=REMI)	
    return;
  struct TreeNode* arg1=t->child[0];
  struct TreeNode* arg2=t->child[1];
 	if (arg1->kind == OpK)
		temp_var_seg--;
	if (arg2 && arg2->kind== OpK)
		temp_var_seg--;
	if(arg1->kind==OpK&&arg2->kind==OpK)
		temp_var_seg++;
	t->temp_var = temp_var_seg;
	temp_var_seg++;

}
char* new_label()
{
  char temp[20];
  char *label;
  sprintf(temp,"label%d",label_seg++);
  label=strdup(temp);
  return label;
}

void stmt_get_label(struct TreeNode* t)
{ 
	if(t==NULL)
	  return;
    switch(t->kind)
	{
      case (CompK):
		  {
             struct TreeNode *last;
			 struct TreeNode *p;
			 p=t->child[0];
			 while(p&&p->nodekind==DeclK)
			 {
				 p=p->sibling;
			 }
			 if(t->Label.begin_label==NULL)
			   t->Label.begin_label=new_label();
		     p->Label.begin_label=t->Label.begin_label;
			 for(;p;p=p->sibling)
			 {
               last=p;
			   recursive_get_label(p);
			 }
			 if(last->Label.next_label==NULL)
			   last->Label.next_label=new_label();
			  t->Label.next_label=last->Label.next_label;
			 if(t->sibling)
			 {
				if(t->Label.next_label==NULL)
				   t->Label.next_label=new_label();
			    t->sibling->Label.begin_label=t->Label.next_label;
			 }
		  }
		  break;
	
	 case(IfK):
        {
        	struct TreeNode *e = t->child[0];
			struct TreeNode *s1 = t->child[1];
			struct TreeNode *s2 = t->child[2];

			e->Label.true_label = new_label();

			if (t->Label.next_label == NULL)
 				t->Label.next_label = new_label();
			s1->Label.next_label = t->Label.next_label;
			if (t->sibling)
			{
				t->sibling->Label.begin_label =t->Label.next_label;
			}

			if (s2)
			{
				e->Label.false_label = new_label();
				s2->Label.next_label = t->Label.next_label;
			}
			else
			{
				e->Label.false_label = t->Label.next_label;
			}
			recursive_get_label(e);
			recursive_get_label(s1);
			if (s2)
				recursive_get_label(s2);
		}
		break;
	 case(WhileK):
		{
          struct TreeNode *e = t->child[0];
			struct TreeNode *s1 = t->child[1];
			e->Label.true_label = new_label();

			if (t->Label.next_label == NULL)
				t->Label.next_label = new_label();
			s1->Label.next_label = t->Label.next_label;
			if (t->sibling)
				t->sibling->Label.begin_label = t->Label.next_label;
			e->Label.false_label = t->Label.next_label;
			recursive_get_label(e);	
			recursive_get_label(s1);
		}
		break;

      case(ForK):
		{
			/* if e2 is null ,it will leads to a dead loop*/
			struct TreeNode *e2 = t->child[1];
			struct TreeNode *s=t->child[3];
			if(e2)
		    	e2->Label.true_label = new_label();

			if (t->Label.next_label == NULL)
				t->Label.next_label = new_label();
			s->Label.next_label = t->Label.next_label;
			if (t->sibling)
				t->sibling->Label.begin_label = t->Label.next_label;
			if(e2)
		    	e2->Label.false_label = t->Label.next_label;
			if(e2)
			 recursive_get_label(e2);	
			recursive_get_label(s);

		}
		break;
	  case(AssignK):
		{
         	if (t->Label.next_label == NULL)
 				t->Label.next_label = new_label();
			if (t->sibling)
				t->sibling->Label.begin_label = t->Label.next_label;


		}
	  default:break;
	  }
}
void expr_get_label(struct TreeNode* t)
{
   if(t==NULL)
	 return;
   if(t->kind!=OpK)
	 return;
   if(!(t->attr.op==AND||t->attr.op==OR||t->attr.op==NOT))
	 return;
   struct TreeNode* e1=t->child[0];
   struct TreeNode* e2=t->child[1];
   switch(t->attr.op)
   {
	   case(AND):
		   {
             e1->Label.true_label = new_label();
	         e2->Label.true_label = t->Label.true_label;
	         e1->Label.false_label = t->Label.false_label;
			 e2->Label.false_label = t->Label.false_label;
		   }
		   break;
	   case(OR):
		   {
             e1->Label.true_label = t->Label.true_label;
	         e2->Label.true_label = t->Label.true_label;
	         e1->Label.false_label =new_label();
		     e2->Label.false_label = t->Label.false_label;
		   }
		   break;
	   case(NOT):
		   {
             e1->Label.true_label=t->Label.true_label;
			 e1->Label.false_label=t->Label.false_label;
		   }
		   break;
		   /*
		case(EQ):
		case(LE):
		case(GE):
	    case(LT):
		case(GT):
		case(NEQ):
		   {
             e1->Label.true_label = strdup(t->Label.true_label);
	         e2->Label.true_label = strdup(t->Label.true_label);
	         e1->Label.false_label = strdup(t->Label.false_label);
		     e2->Label.false_label = strdup(t->label.false_label);
		   }
		   break;
		   */
   }
   if(e1)
	 recursive_get_label(e1);
   if(e2)
	 recursive_get_label(e2);
}
void recursive_get_label(struct TreeNode* t)
{
  if(t==NULL)
	return;
  if(t->nodekind==StmtK)
	stmt_get_label(t);
  else if(t->nodekind==ExpK)
	expr_get_label(t);
	  
}

void gen_decl(char* codefile,struct TreeNode* t,FILE* code)
{
  printf("gen_decl\n");
  fprintf(code,"#%s generating AT&T assembly code\n",codefile);
  fprintf(code,".section .data\n");
  struct TreeNode* p;
  for(;t->nodekind==DeclK;t=t->sibling)
  {
    for(p=t->child[1];p;p=p->sibling)
	  if(p->type==Integer)
	  {
		struct symbol* s;
		s=search(p->attr.name);
		if(s)
	    	fprintf(code,"_%s:\n   .int 0\n",s->name);
	  }
	  else if(p->type==Char)
	  {
        struct symbol* s;
		s=search(p->attr.name);
		if(s)
	    	fprintf(code,"_%s:\n   .byte 0\n",s->name);

	  }
  }
  int i;
  for(i=0;i<=temp_var_seg;i++)
  {
    fprintf(code,"t%d:\n   .int 0\n",i);
  }
  //allocate one more temporary variable
  fprintf(code,"temp:\n   .int 0\n");
  fprintf(code,"inputInt:\n   .asciz \"%%d\"\n");
  fprintf(code,"inputChar:\n   .asciz \"%%c\"\n");

  fprintf(code,"int_buffer:\n   .asciz \"%%d\\n\"\n");
  fprintf(code,"char_buffer:\n   .asciz \"%%c\\n\"\n");
  printf("gen_decl completed\n");
}

void stmt_gen_code(char* codefile,struct TreeNode* t,FILE* code)
{
	if(t==NULL)
	  return;
	if(t->kind==CompK)
   {
	 int i;
     struct TreeNode* p;

	 for(i=0;t->child[i];i++)
	 {
      recursive_gen_code(codefile,t->child[i],code);
	  for(p=t->child[i]->sibling;p;p=p->sibling)
		recursive_gen_code(codefile,p,code);
	 }
   }
    if(t->kind==WhileK)
   {
	 if(t->Label.begin_label==NULL)
	   t->Label.begin_label=new_label();
	 fprintf(code,"%s:\n",t->Label.begin_label);
     recursive_gen_code(codefile,t->child[0],code);
	 fprintf(code,"\%s:\n",t->child[0]->Label.true_label);
	 recursive_gen_code(codefile,t->child[1],code);
	 fprintf(code,"\tjmp %s\n",t->Label.begin_label);
	 fprintf(code,"\%s:\n",t->Label.next_label);
	 fprintf(code,"\n");
   }
    if(t->kind==IfK)
   {
      recursive_gen_code(codefile,t->child[0],code);
      fprintf(code,"\%s:\n",t->child[0]->Label.true_label);
      recursive_gen_code(codefile,t->child[1],code);
	  if(t->child[2])
	  {
        fprintf(code,"\%s:\n",t->child[0]->Label.false_label);
        recursive_gen_code(codefile,t->child[2],code);
	  }
	  else
	  { fprintf(code,"\%s:\n",t->Label.next_label);
		  fprintf(code,"\n");
	  }
   }
   if(t->kind==ForK)
   {
      if(t->child[0])
      recursive_gen_code(codefile,t->child[0],code);
     if(t->child[1]==NULL)
	 {
	   recursive_gen_code(codefile,t->child[3],code);
       if(t->child[2])
	     recursive_gen_code(codefile,t->child[2],code);
	   if(t->child[3])
	     fprintf(code,"\tjmp %s\n",t->child[3]->Label.begin_label);
	   
	 }
	 else{
		 char* label;
        if(t->child[0]){
           label=new_label();
		  if(!label)
		  {
             printf("out of memory\n");
			 exit(1);
		  }
		  fprintf(code,"%s:\n",label);
		}
        recursive_gen_code(codefile,t->child[1],code);
	    fprintf(code,"\%s:\n",t->child[1]->Label.true_label);
        recursive_gen_code(codefile,t->child[3],code);
        if(t->child[2])
	     recursive_gen_code(codefile,t->child[2],code);
		if(t->child[0])
		  fprintf(code,"\tjmp %s\n",label);
		else
	      fprintf(code,"\tjmp %s\n",t->Label.begin_label);
	    fprintf(code,"\%s:\n",t->Label.next_label);
	 }
	 fprintf(code,"\n");
   }
    if(t->kind==InputK)
   {
     struct TreeNode* p=t->child[0];
	 struct symbol* s;
	 s=search(p->attr.name);
      if(s==NULL)
      {
		  printf("No such ID\n");
		  exit(1);
	  }
	  /*
     fprintf(code,"\tmovl $3,%%eax\n");
	 fprintf(code,"\tmovl $0,%%ebx\n");
	
	 fprintf(code,"\tmovl $_%s,%%ecx\n",s->name);
	 if(p->type==Integer)
	   fprintf(code,"\tmovl $2,%%edx\n");
	 else  
        fprintf(code,"\tmovl $1,%%edx\n");
     fprintf(code,"\tint $0x80\n");
	 */
	  if(p->type==Integer)
	  fprintf(code,"\tpushl $_%s\n\tpushl $inputInt\n\tcall scanf\n\taddl $8,%%esp\n",s->name);
	  else
        fprintf(code,"\tpushl $_%s\n\tpushl $inputChar\n\tcall scanf\n\taddl $8,%%esp\n",s->name);

	 fprintf(code,"\n");
   }
	if(t->kind==PrintK)
	{
      struct TreeNode* p=t->child[0];
	  struct symbol* s;
	  s=search(p->attr.name);
     if(s==NULL)
      {
		  printf("No such ID\n");
		  exit(1);
	  }
	if(p->type==Integer)
        fprintf(code,"\tpushl _%s\n\tpushl $int_buffer\n\tcall printf\n\taddl $8,%%esp\n",s->name);
	 else
	   fprintf(code,"\tpushl _%s\n\tpushl $char_buffer\n\tcall printf\n\taddl $8,%%esp\n",s->name);
   
	 fprintf(code,"\n");
	}
     if(t->kind==AssignK)
	{
        struct TreeNode* e1=t->child[0];
        struct TreeNode* e2=t->child[1];
        struct symbol* s;
      		 recursive_gen_code(codefile,e1,code);
			 recursive_gen_code(codefile,e2,code);
			 if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovl $%d,%%eax\n",e2->attr.val);
			 }
			 else
			   fprintf(code,"\tmovl t%d,%%eax\n",e2->temp_var);

			 if(e1->kind==IdK)
			 {
                s=search(e1->attr.name);
			    if(s)
				 fprintf(code,"\tmovl %%eax,_%s\n",s->name);
			 }
			 else
                 fprintf(code,"\tmovl %%eax,t%d\n",e1->temp_var);
           fprintf(code,"\n");
	}
}
void expr_gen_code(char* codefile,struct TreeNode* t,FILE* code)
{
  if(t==NULL)
	return;
  struct TreeNode* e1=t->child[0];
  struct TreeNode* e2=t->child[1];
   recursive_gen_code(codefile,e1,code);
  if(t->attr.op==AND)
	fprintf(code,"\%s:\n",e1->Label.true_label);				
  if(t->attr.op==OR)
	fprintf(code,"\%s:\n",e1->Label.false_label);
  if(t->attr.op==NOT)
	fprintf(code,"\%s:\n",e1->Label.true_label);
  if(e2!=NULL)
    recursive_gen_code(codefile,e2,code);
  /*
  if(t->kind==IdK)
  {
	struct symbol* s;
    s=search(t->attr.name);
    if(t->type==Integer)
	{
	 if(t->Label.true_label==NULL)
	   return;
	 if(s)
      fprintf(code,"\tcmp $0,_%s\n",s->name);
	 fprintf(code,"\tje %s\n",t->Label.false_label);
	 fprintf(code,"\tjmp %s\n",t->Label.true_label);
	}
  }
  if(t->kind==ConstK)
  {
    if(t->type==Integer)
	{
     if(t->Label.true_label==NULL)
	   return;
     fprintf(code,"\tcmp $0,$%d\n",t->attr.val);
	 fprintf(code,"\tje %s\n",t->Label.false_label);
	 fprintf(code,"\tjmp %s\n",t->Label.true_label);
	}
  }
*/
  if(t->kind==OpK)
  {
   struct symbol* s;
   switch(t->attr.op)
   {
	   	   case(PLUS):
		   {
              if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
				 fprintf(code,"\taddl _%s,%%eax\n",s->name);
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\taddl $%d,%%eax\n",e2->attr.val);
			 }
			 else
			   fprintf(code,"\taddl t%d,%%eax\n",e2->temp_var);
             fprintf(code,"\tmovl %%eax,t%d\n",t->temp_var);
            
		   }
		   break;
	   case(MINUS):
		   {

             if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e2->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e2->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e2->temp_var);
              if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tsubl _%s,%%eax\n",s->name);
			 }
			 else if(e1->kind==ConstK)
			 {
               fprintf(code,"\tsubl $%d,%%eax\n",e1->attr.val);
			 }
			 else
			   fprintf(code,"\tsubl t%d,%%eax\n",e1->temp_var);
             fprintf(code,"\tmovl %%eax,t%d\n",t->temp_var);

		   }
		   break;
	   case(TIMES):
		   {
            
              if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%ebx\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%ebx\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
				 fprintf(code,"\timull _%s,%%ecx\n",s->name);
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\timull $%d,%%ecx\n",e2->attr.val);
			 }
			 else
			   fprintf(code,"\timull t%d,%%ecx\n",e2->temp_var);
             fprintf(code,"\tmovl %%ecx,t%d\n",t->temp_var);
            

		   }
		   break;
	   case(OVER):
		   {
              if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s){
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
				 fprintf(code,"\tmolv %%ebx,temp\n");
				 fprintf(code,"\tmovw temp,%%ax\n\tmovw temp+2 %%dx\n");
			   }
			 }else if(e1->kind==ConstK)
			 {
			   fprintf(code,"\tmovl $%d,%%ebx\n",e1->attr.val);
               fprintf(code,"\tmolv %%ebx,temp\n");
			   fprintf(code,"\tmovw temp,%%ax\n\tmovw temp+2 %%dx\n");

			 }
			  else
			  {
				fprintf(code,"\tmovl t%d,%%ebx\n",e1->temp_var);
                fprintf(code,"\tmolv %%ebx,temp\n");
			    fprintf(code,"\tmovw temp,%%ax\n\tmovw temp+2 %%dx\n");

			  }
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovw _%s,%%cx\n",s->name);
				 fprintf(code,"\tdivl %%cx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovw $%d,%%cx\n",e2->attr.val);
               fprintf(code,"\tdivl %%cx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovw t%d,%%cx\n",e2->temp_var);
               fprintf(code,"\tdivl %%cx\n");

			 }
             fprintf(code,"\tmovw %%ax,t%d\n",t->temp_var);
		   }
		   break;
		case(REMI):
		   {
             if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s){
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
				 fprintf(code,"\tmolv %%ebx,temp\n");
				 fprintf(code,"\tmovw temp,%%ax\n\tmovw temp+2 %%dx\n");
			   }
			 }else if(e1->kind==ConstK)
			 {
			   fprintf(code,"\tmovl $%d,%%ebx\n",e1->attr.val);
               fprintf(code,"\tmolv %%ebx,temp\n");
			   fprintf(code,"\tmovw temp,%%ax\n\tmovw temp+2 %%dx\n");

			 }
			  else
			  {
				fprintf(code,"\tmovl t%d,%%ebx\n",e1->temp_var);
                fprintf(code,"\tmolv %%ebx,temp\n");
			    fprintf(code,"\tmovw temp,%%ax\n\tmovw temp+2 %%dx\n");

			  }
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovw _%s,%%cx\n",s->name);
				 fprintf(code,"\tdivl %%cx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovw $%d,%%cx\n",e2->attr.val);
               fprintf(code,"\tdivl %%cx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovw t%d,%%cx\n",e2->temp_var);
               fprintf(code,"\tdivl %%cx\n");

			 }
             fprintf(code,"\tmovw %%dx,t%d\n",t->temp_var);
            
		   }
		   break;
		case(DMINUS):
		   {
              if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s){
				 fprintf(code,"\tdec _%s\n",s->name);
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
                 fprintf(code,"\tmovw %%eax,t%d\n",t->temp_var);
			   }
			 }			  
			  else
			  {
				fprintf(code,"\tdec t%d\n",e1->temp_var);
                fprintf(code,"\tmovl t%d,%%eax\n",e1->attr.val);
                fprintf(code,"\tmovw %%eax,t%d\n",t->temp_var);
			  }

		   }
		   break;
		case(DPLUS):
		   {
			   if(e1->kind==IdK)
              {
				 fprintf(code,"\tinc _%s\n",s->name);
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
                 fprintf(code,"\tmovw %%eax,t%d\n",t->temp_var);
			   
			 }			  
			  else
			  {
				fprintf(code,"\tinc t%d\n",e1->temp_var);
                fprintf(code,"\tmovl t%d,%%eax\n",e1->attr.val);
                fprintf(code,"\tmovw %%eax,t%d\n",t->temp_var);
			  }

		   }
			break;

      case(LT):
			{
                if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
                 fprintf(code,"\tcmp %%eax,%%ebx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovl $%d,%%ebx\n",e2->attr.val);
               fprintf(code,"\tcmp %%eax,%%ebx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovl t%d,%%ebx\n",e2->temp_var);
               fprintf(code,"\tcmp %%eax,%%ebx\n");

			 }
             fprintf(code,"\tjg %s\n",t->Label.true_label);
			 fprintf(code,"\tjmp %s\n",t->Label.false_label);

			}
		    break;
	  case(EQ):
			{
               if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
                 fprintf(code,"\tcmp %%eax,%%ebx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovl $%d,%%ebx\n",e2->attr.val);
               fprintf(code,"\tcmp %%eax,%%ebx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovl t%d,%%ebx\n",e2->temp_var);
               fprintf(code,"\tcmp %%eax,%%ebx\n");

			 }
             fprintf(code,"\tje %s\n",t->Label.true_label);
			 fprintf(code,"\tjmp %s\n",t->Label.false_label);

			}
            break;
	 case(LE):
			{
			   if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
                 fprintf(code,"\tcmp %%eax,%%ebx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovl $%d,%%ebx\n",e2->attr.val);
               fprintf(code,"\tcmp %%eax,%%ebx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovl t%d,%%ebx\n",e2->temp_var);
               fprintf(code,"\tcmp %%eax,%%ebx\n");

			 }
             fprintf(code,"\tjge %s\n",t->Label.true_label);
			 fprintf(code,"\tjmp %s\n",t->Label.false_label);


			}
            break;
	 case(GE):
			{
               if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
                 fprintf(code,"\tcmp %%eax,%%ebx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovl $%d,%%ebx\n",e2->attr.val);
               fprintf(code,"\tcmp %%eax,%%ebx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovl t%d,%%ebx\n",e2->temp_var);
               fprintf(code,"\tcmp %%eax,%%ebx\n");

			 }
             fprintf(code,"\tjle %s\n",t->Label.true_label);
			 fprintf(code,"\tjmp %s\n",t->Label.false_label);

			}
			break;
	 case(GT):
			{
                if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
                 fprintf(code,"\tcmp %%eax,%%ebx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovl $%d,%%ebx\n",e2->attr.val);
               fprintf(code,"\tcmp %%eax,%%ebx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovl t%d,%%ebx\n",e2->temp_var);
               fprintf(code,"\tcmp %%eax,%%ebx\n");

			 }
             fprintf(code,"\tjl %s\n",t->Label.true_label);
			 fprintf(code,"\tjmp %s\n",t->Label.false_label);

			}
			break;
	 case(NEQ):
			{
              if(e1->kind==IdK)
			 {
               s=search(e1->attr.name);
			   if(s)
				 fprintf(code,"\tmovl _%s,%%eax\n",s->name);
			 }else if(e1->kind==ConstK)
			   fprintf(code,"\tmovl $%d,%%eax\n",e1->attr.val);
			  else
				fprintf(code,"\tmovl t%d,%%eax\n",e1->temp_var);
              if(e2->kind==IdK)
			 {
               s=search(e2->attr.name);
			   if(s)
			   {
				 fprintf(code,"\tmovl _%s,%%ebx\n",s->name);
                 fprintf(code,"\tcmp %%eax,%%ebx\n");
			   }
			 }
			 else if(e2->kind==ConstK)
			 {
               fprintf(code,"\tmovl $%d,%%ebx\n",e2->attr.val);
               fprintf(code,"\tcmp %%eax,%%ebx\n");
			 }
			 else
			 {
			   fprintf(code,"\tmovl t%d,%%ebx\n",e2->temp_var);
               fprintf(code,"\tcmp %%eax,%%ebx\n");

			 }
             fprintf(code,"\tjne %s\n",t->Label.true_label);
			 fprintf(code,"\tjmp %s\n",t->Label.false_label);

			}
			break;
  }
  
}
}
void gen_header(char* codefile,FILE* code)
{
  printf("gen_header\n");
  fprintf(code,".code32\n");
  printf("header generation completed\n");
}
void get_label(struct TreeNode* t)
{
  struct TreeNode *p=t;
  p->Label.begin_label=strdup("_start");
    recursive_get_label(p);
}
void recursive_gen_code(char* codefile,struct TreeNode* t,FILE* code)
{
  if(t->nodekind==StmtK)
	stmt_gen_code(codefile,t,code);
  else if(t->nodekind==ExpK&&t->kind==OpK)
	expr_gen_code(codefile,t,code);
	
}
void gen_code(char* codefile,struct TreeNode* t,FILE* code)
{
 printf("gen_code\n");
  gen_header(codefile,code);
  struct TreeNode *p=t->child[0];
  if(p->nodekind==DeclK)
	gen_decl(codefile,p,code);
  fprintf(code,".section .text\n");
  fprintf(code,".globl _start\n");
  fprintf(code,"_start:\n");
  recursive_gen_code(codefile,t,code);
  fprintf(code,"\tmovl $0,%%ebx\n");
  fprintf(code,"\tmovl $1,%%eax\n");
  fprintf(code,"\tint $0x80\n");
}

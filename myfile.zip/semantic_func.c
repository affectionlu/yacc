#  include <stdio.h>
#  include <unistd.h>
#  include <stdlib.h>
#  include <stdarg.h>
#  include <string.h>
#  include <math.h>
#  include "semantic.h"

/* symbol table */
/* hash function */
static unsigned
symhash(char * sym)
{
  unsigned int hash=0;
  unsigned c;
  while(c==*sym++) hash=hash*9^c;

  return hash;
}

struct symbol *
lookup(char * sym)
{
  struct symbol *sp=&symtab[symhash(sym)%NHASH];
  int scount=NHASH;
  while(--scount>=0){
   if(sp->name&&strcmp(sp->name,sym)){return sp;}
   if(!sp->name){
      sp->name=strdup(sym);
	  sp->value=0;
	  sp->type=-1;
	  return sp;
   }
   if(++sp>=symtab+NHASH)sp=symtab;
  }
  /*symbol table is full */
  yyerror("symbol table is full\n");
  abort();
}

struct symlist *newsymlist(struct symbol *sym,struct symlist * next){
  struct symlist *sl=malloc(sizeof(struct symlist));
  if(!sl){
    yyerror("out of space");
	exit(0);
  }
  sl->sym=sym;
  sl->next=next;
  return sl;
}

void symlistfree(struct symlist *sl)
{
  struct symlist *nsl;
  while(sl){
    nsl=sl->next;
	free(sl);
	sl=nsl;
  }
}

struct ast *newast(int nodetype,struct ast *l,struct ast *r)
{
   struct ast * m_ast=malloc(sizeof(struct ast));
   if(!m_ast){
     yyerror("out of space");
	 exit(0);
   }
   m_ast->treenode_index=Treenode_index++;
   m_ast->nodetype=nodetype;
   m_ast->l=l;
   m_ast->r=r;
   return m_ast;
}

struct ast* newcmp(int cmptype,struct ast * l,struct ast *r)
{
  struct ast * m_ast=malloc(sizeof(struct ast));
   if(!m_ast){
     yyerror("out of space");
	 exit(0);
   }
  m_ast->treenode_index=Treenode_index++;
  m_ast->nodetype='0'+cmptype;
  m_ast->l=l;
  m_ast->r=r;
  return m_ast;
}

struct ast *newfunc(int functype, struct ast *l)
{
  struct fncall * m_ast=malloc(sizeof(struct fncall));
   if(!m_ast){
     yyerror("out of space");
	 exit(0);
   }
  m_ast->treenode_index=Treenode_index++;
  m_ast->nodetype='C';
  m_ast->l=l;
  m_ast->functype=functype;
  return (struct ast *)m_ast;
}

struct ast *newref(struct symbol *s)
{
    struct symref* a=malloc(sizeof(struct symref));
    if(!a){
     yyerror("out of sapce");
	 exit(0);
	}
	a->nodetype='N';
	a->s=s;
	a->treenode_index=Treenode_index++;
	return (struct ast *)a;
}

struct ast *newasgn(struct symref *ref, struct ast *v)
{
  struct symasgn *a=malloc(sizeof(struct symasgn));
  if(!a){
     yyerror("out of sapce");
	 exit(0);
  }
  a->treenode_index=Treenode_index++;
  a->nodetype='=';
  a->ref=ref;
  a->v=v;
  return (struct ast*)a;
}

struct ast *newnum(int i)
{
   struct numval* a=malloc(sizeof(struct numval));
   if(!a){
     yyerror("out of sapce");
	 exit(0);
   }
   a->treenode_index=Treenode_index++;
   a->nodetype='K';
   a->i=i;
   return (struct ast*)a;
}

struct ast *newflow(int nodetype, struct ast *cond, struct ast *tl, struct ast *el,struct ast * es)
{
  struct flow* a=malloc(sizeof(struct flow));
  if(!a){
     yyerror("out of sapce");
	 exit(0);
   }
  a->nodetype=nodetype;
  a->treenode_index=Treenode_index++;
  a->cond=cond;
  a->tl=tl;
  a->el=el;
  a->es=es;
  return (struct ast*)a;
}

struct ast *newdelc(int type,struct symlist * syml)
{
  struct delstmt *a=malloc(sizeof(struct delstmt));
   if(!a){
     yyerror("out of sapce");
	 exit(0);
   }
  a->treenode_index=Treenode_index++;
  a->nodetype='D';
  a->symlist=syml;
  a->type=type;
  return (struct ast*)a;
}
struct ast* newreval(int i)
{
  struct reval *a=malloc(sizeof(struct reval));
  if(!a){
    yyerror("out of space");
	exit(0);
  }
  a->nodetype='E';
  a->treenode_index=Treenode_index++;
  a->i=i;
}

void tree_free(struct ast *a)
{
  if(a==NULL)
	return;
  switch(a->nodetype)
  {
   /* two subtrees */
   case '+':
   case '-':
   case '*':
   case '/':
   case '1':  case '2':  case '3':  case '4':  case '5':  case '6':
   case '%':
   case '|':
   case '&':
   case '^':
   case 'Y':
   case 'Z':
   case 'L':
   case 'A':
   case 'R':
	   tree_free(a->l);tree_free(a->r);free(a);break;
   /*one subtree */
   case '!':
   case '~':
   case 'P':
   case 'J':
   case 'M':
   case 'C':
       tree_free(a->l);free(a);break;
   /* no subtree */
   case 'D':
	       symlistfree(((struct delstmt *)a)->symlist);free(a);break;
   case 'K':
   case 'E':
   case 'N':
		free(a);
	   break;
   case '=':
	   tree_free(((struct symasgn*)a)->v);free(a);
	   break;
   case 'I':case 'W': case 'F':
	   if(((struct flow*)a)->cond) tree_free(((struct flow*)a)->cond);
	   if(((struct flow*)a)->tl) tree_free(((struct flow*)a)->tl);
       if(((struct flow*)a)->el) tree_free(((struct flow*)a)->el);
       if(((struct flow*)a)->es) tree_free(((struct flow*)a)->es);
	   free(a);
	   break;
   default:printf("free bad node\n");break;
  }
  }

void yyerror(char *s,...)
{
  va_list ap;
  va_start(ap, s);

  fprintf(stderr, "%d: error: ", yylineno);
  vfprintf(stderr, s, ap);
  fprintf(stderr, "\n");

}
//unfinished
static int callbuiltin(struct fncall*f)
{
  enum bifs functype=f->functype;
  char v_char;
  int c_int;
  int r_value;
  switch(functype)
  {
	  case B_readChar:
    	if(read(0,&v_char,1)==-1)
		  yyerror(" get input from console failed\n");
		return (int)(v_char-'0');
	  case B_writeChar:
		//uncomplished
      case B_readInt:
	
	  case B_writeInt:

	  default:yyerror("unknown built-in function: %d",functype);
			  return 0;

  }
  return 0;
}

void travel(struct ast* a)
{
  char *ss="%%%%%%";
  struct symlist *next_s;
  if(a==NULL)
	return;
  switch(a->nodetype)
  {
   /* two subtrees */
   case '+':
   case '-':
   case '*':
   case '/':
   case '%':
   case '|':
   case '&':
   case '^':
	       travel(a->l);
		   travel(a->r);
	       printf("%i:Expr,\t,op:%c,\t,Children:%i  %i\n",a->treenode_index,(char)a->nodetype,(a->l)->treenode_index,(a->r)->treenode_index);
           break;
   case '1':ss=">";goto label1;
   case '2':ss="<";goto label1;
   case '3':ss="!=";goto label1;
   case '4':ss="==";goto label1;
   case '5':ss=">=";goto label1;
   case '6':ss="<=";
      label1:  travel(a->l);
		       travel(a->r);
		       printf("%i:Expr,\t op:%s,\t Children: %i %i \n",a->treenode_index,
				ss,a->l->treenode_index,a->r->treenode_index);
		       break;
   case 'L':
		   travel(a->l);
		   travel(a->r);
		   break;
   case 'Y':ss="<<";goto label2;
   case 'Z':ss=">>";goto label2;
   case 'A':ss="&&";goto label2;
   case 'R':ss="||";
       label2: travel(a->l);
		       travel(a->r);
               printf("%i:Expr,\t op=%s,\t Children: %i %i \n",a->treenode_index,
				ss,a->l->treenode_index,a->r->treenode_index);
		       break;
  /*one subtree */
   case '!':ss="!";goto label3;
   case '~':ss="~";goto label3;
   case 'P':ss="++";goto label3;
   case 'M':ss="-";goto label3;
   case 'J':ss="--";
           label3: travel(a->l);
                   printf("%i:Expr,\t op=%s,\t Children: %i\n",a->treenode_index,
				    ss,a->l->treenode_index);
		           break;

   /* no subtree */
   case 'K':
	       printf("%i:INT Number,\t,value:%i,\tChildren:\n",a->treenode_index,((struct numval*)a)->i);
		   break;
   case 'N':
            printf("%i:ID Declaration,\t,symbol:%s,\t,Children:\n",a->treenode_index,((struct symref*)a)->s->name);
           break;

 /* statement */
   case '=':
           travel((struct ast *)(((struct symasgn*)a)->ref));
		   travel(((struct symasgn*)a)->v);
		    printf("%i:Expr,\t op:=,\t Children:%i  %i\n",a->treenode_index,((struct symasgn*)a)->ref->treenode_index,
			    ((struct symasgn*)a)->v->treenode_index);
		   break;
   case 'c':
		   switch(((struct fncall*)a)->functype)
		   {
             case B_readInt :
				            ss="readint";break;
			 case B_readChar :
							ss="readchar";break;
			 case B_writeInt :
						    ss="writeint";break;
			 case B_writeChar :
							 ss="writechar";break;
			 default:ss="Unknown function call";break;
		   }

		    travel(((struct fncall*)a)->l);
			printf("%i,Call built-in functioni: %s,\t Children:%i\n",a->treenode_index,ss,((struct fncall*)a)->l->treenode_index);
	        break;
   case 'D':
			next_s=NULL;
			if(((struct delstmt*)a)->type=INT)
			  ss="INT";
			else
			  ss="CHAR";
			printf("%i:%s Declaration,    \t Children:\n",a->treenode_index,ss);
			next_s=(((struct delstmt*)a)->symlist);
            printf("  Declare variable:\t");
		   while(next_s){
               printf("%s\t",next_s->sym->name);
			   next_s=next_s->next;
		   }
           printf("\n");
           break;
   case 'I':
           travel(((struct flow*)a)->cond);
		   printf("come here\n");
		   if(((struct flow*)a)->tl )
			 travel(((struct flow*)a)->tl);
		   printf("not come here\n");
		   if(((struct flow*)a)->el)
		   travel(((struct flow*)a)->el);
		   if(((struct flow*)a)->tl==NULL){
              printf("%i,IF Statement,\t    \t,Children:%i \n",a->treenode_index,((struct flow*)a)->cond->treenode_index);break;
		   }
		   if(((struct flow*)a)->el==NULL)
             printf("%i,IF Statement,\t    \t,Children:%i %i\n",a->treenode_index,
				((struct flow*)a)->cond->treenode_index,((struct flow*)a)->tl->treenode_index);
		   else
			printf("%i,IF Statement,\t    \t,Children:%i %i %i\n",a->treenode_index,
				((struct flow*)a)->cond->treenode_index,((struct flow*)a)->tl->treenode_index,
				((struct flow*)a)->el->treenode_index);
		   break;
   case 'W':
           travel(((struct flow*)a)->cond);
           if(((struct flow*)a)->tl)
		     travel(((struct flow*)a)->tl);
		   if(((struct flow*)a)->tl==NULL)
		      printf("%i,While Statement,\t    Children:%i \n",a->treenode_index,
				((struct flow*)a)->cond->treenode_index); 
		   else{
               printf("%i,While Statement,\t    \t,Children:%i %i\n",a->treenode_index,
				((struct flow*)a)->cond->treenode_index,((struct flow*)a)->tl->treenode_index);
		   }
           break;
   case 'F':
           travel(((struct flow*)a)->cond);
		   travel(((struct flow*)a)->tl);
           travel(((struct flow*)a)->el);
		   travel(((struct flow*)a)->es);
           printf("%i,For Statement,\t    \t,Children:%i %i %i %i\n",a->treenode_index,
				((struct flow*)a)->cond->treenode_index,((struct flow*)a)->tl->treenode_index,
				((struct flow*)a)->el->treenode_index,((struct flow*)a)->es->treenode_index);
           break;
   default:printf("travel bad node \n");break;
  }

}
int main(int argc,char ** argv)
{
  Treenode_index=0;
  int i;
  if(argc < 2) { /* just read stdin */
    curfilename = "(stdin)";
	yyparse();
  } else
  for(i = 1; i < argc; i++) {
    FILE *f = fopen(argv[i], "r");
    :q

  
    if(!f) {
      perror(argv[1]);
      return (1);
    }
    curfilename = argv[i];	/* for addref */

    yyrestart(f);
    yylineno = 1;
	yyparse();
    fclose(f);
  }
   return 0; 
 }

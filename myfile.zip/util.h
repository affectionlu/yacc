#  include <stdio.h>
#  include <unistd.h>
#  include <stdlib.h>
#  include <stdarg.h>
#  include <string.h>
#  include <math.h>
# include "semantic.tab.h"

#define Void 0
#define Integer 1
#define Char 2

struct symbol{
  char *name; /* ID name */
  int value;
  int lineno;
  char v;
  int type;   /* 0  void 1 integer 2 char 3 boolean*/
};
enum {StmtK,ExpK,DeclK};
enum {IfK,WhileK,AssignK,ForK,CompK,InputK,PrintK};
enum {OpK,ConstK,IdK,TypeK};
enum {VarK};

#define MAXCHILDREN 4
struct TreeNode
   { 
	struct TreeNode * child[MAXCHILDREN];
     struct TreeNode * sibling;
	 int lineno;
     int nodekind;                    	 
     int kind;
     union{ int op;                             
	 int val;
	 char *zf;
	 char *name; }attr;             
	 int type;
	 int temp_var;
	 struct TreeNode* owner;
     union{
	    struct {
		       char* true_label;
		       char* false_label;
		};
	    struct {
		        char* begin_label;
				char* next_label;
		};
	 }Label;
   };

#define NHASH 9997
static FILE *code;
static struct symbol symtab[NHASH];
static int temp_var_seg=0;
static int label_seg=0;
static struct TreeNode* TreeRoot;
struct symbol *lookup(char*);
struct symbol * search(char*);
int addType(char*,int);
int addValue(char*,int,char);
int getType(char*);
void init_symtab();


/*functions for code generating*/
void get_temp_var(struct TreeNode *t);
char* new_label();
void recursive_get_label(struct TreeNode *t);
void stmt_get_label(struct TreeNode *t);
void expr_get_label(struct TreeNode *t);
void gen_header(char* codefile,FILE* code);
void gen_decl(char* codefile, struct TreeNode *t,FILE* code);
void recursive_gen_code(char* codefile, struct TreeNode *t,FILE* code);
void stmt_gen_code(char* codefile, struct TreeNode *t,FILE* code);
void expr_gen_code(char* codefile, struct TreeNode *t,FILE* code);
void get_label(struct TreeNode* t);
void gen_code(char* codefile,struct TreeNode* t,FILE* code);


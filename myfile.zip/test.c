 main()
{
 /*I love you ,
  * dear!
  */
 int a,c;
 int i;
 int b;
 a=0;
 b=1;
 c=0;
 if(a==0)
   a=1;
for(a=0;a<5;++a)
{ 
  b=a+1;
  a=b*a+1;
}

if(a>1||b==0&&c==0)
{
 }
 
 
 i=0;
 while(i<10)
 {
   a=a-10;//comment
   i=i+1;
 }
 
}

/*header files
 * created by affection(liu yi qing)-2017.11.28
 */
#define CHAR 0
#define INT 1
char* curfilename;
static unsigned int Treenode_index=0;//for debug use 
/*symbol table*/
struct symbol{
  char *name; /* ID name */
  int value;
  int type;   /* -1 fordefault, 0 for char,1 for int */
};

/* hash table for fixed size */
#define NHASH 9997
struct symbol symtab[NHASH];

struct symbol *lookup(char*);

/* argument list */
struct symlist{
  struct symbol *sym;
  struct symlist *next;
};

struct symlist *newsymlist(struct symbol *sym,struct symlist * next);
void symlistfree(struct symlist *sl);

/*design treenode type
 *  + ，-， *， / ,%,|,~ ,^,&,!
 *  0-7 comparison operator,bit 04 equal,02 less,01 greater
 *  not equal
 *  A logical and
 *  R logical or
 *  M (-3)
 *  P ++
 *  J --
 *  Y <<
 *  Z >>
 *  = assignment stmt
 *  L statement list
 *  I if stmt
 *  W while stmt
 *  F for stmt
 *  D declaration stmti
 *  C built-in function call
 *  N symbol ref
 *  E return stmt
 */
enum bifs{
  B_readInt=1,  /* built-in functions */
  B_readChar,
  B_writeInt,
  B_writeChar
};

/*basic nodes for common nodetype */

struct ast {
  int nodetype;
  int treenode_index;
  struct ast *l;
  struct ast *r;
};

struct delstmt{          /* delclaration stmt */
  int nodetype;          /* type D */
  int treenode_index;    
  int type;
  struct symlist * symlist;  /* ID list */
};

struct fncall {     /* built-in function */
  int nodetype;     /* type C */
  int treenode_index;  
  struct ast *l;    /* list of argument */
  enum bifs functype;
};

struct flow {

  int nodetype;     /* type I or W or F */
  int treenode_index; 
  struct ast * cond;  /* condition */
  struct ast * tl;    /* then */
  struct ast * el;    /* else */
  struct ast * es;    /*extra */
};

struct symasgn {      /* assignment stmt */
  int nodetype;       /* type = */
  int treenode_index;
  struct symref *ref;
  struct ast *v;     /* value */
};

struct symref {
  int nodetype;        /* type N */
  int treenode_index;
  struct symbol *s;
};

struct numval {
  int nodetype;       /* type K */
  int treenode_index;
  int i;
};

struct reval{
  int nodetype;
  int treenode_index;
  int i;
};

/* built an AST */
struct ast * newast(int nodetype,struct ast *l,struct ast *r);
struct ast *newcmp(int cmptype, struct ast *l, struct ast *r);
struct ast *newfunc(int functype, struct ast *l);
struct ast *newref(struct symbol *s);
struct ast *newasgn(struct symref *ref, struct ast *v);
struct ast *newnum(int i);
struct ast *newflow(int nodetype, struct ast *cond, struct ast *tl, struct ast *tr,struct ast* es);
struct ast *newdelc(int type,struct symlist * syml);
struct ast* newreval(int i);
/* travel an AST from top to down */
void travel(struct ast *);

/* delete and free an AST */
void tree_free(struct ast *);

/* interface to the lexer */
extern int yylineno; /*from lexer */
void yyerror(char *,...);

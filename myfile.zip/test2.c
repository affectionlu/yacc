main()
{
 int i,input;
 int a,b,c;
 a=0;
 b=1;
 my_input(input);
//input=10;
 i=0;
 my_print(b);
 while(i<input)
 {
   c=a+b;
   my_print(c);
   a=b;
   b=c;
   i=i+1;
 }
}
